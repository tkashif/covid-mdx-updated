module.exports = {
  plugins: [
    'gatsby-plugin-netlify',
    '@philpl/gatsby-theme-mdx-deck'
  ]
}
