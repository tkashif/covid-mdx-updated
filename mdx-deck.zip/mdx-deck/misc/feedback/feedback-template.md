# Presentation Feedback

### Positives
_What were some aspects of the presentation that the developers excelled at?_

* 

### Improvements
_Describe some improvements they can make with their presentation._

* 

### Goals for Next Time
_What can they do to improve next time?_

* 
