---
name: 'Choosing Idea Week 1 of 3: Dev Tasks'
about: FOR CHOOSING IDEA Week 1 Checklist for Devs
title: "[Topic Name] [Project Name] Week 1 of 3: Dev Tasks"
labels: weekly-dev
assignees: ''

---

# Week 1 of 3: Getting Ideas on (MDX-Deck) Paper
## Week 1 Checklist for Developers
- [ ] Go through entire workshop
         - [ ] **Make sure it completely works on your computer**
         - [ ] Understand at a high level what is happening
- [ ] Convert workshop idea into MDX-Deck Slides on bitprj/mdx-deck
         - [ ] Make speaker notes for all slides
- [ ] Add new interactive component
- [ ] Finalize date and time of presentation (in Week 3) with Head
- [ ] General Slide Checklist Fulfilled
