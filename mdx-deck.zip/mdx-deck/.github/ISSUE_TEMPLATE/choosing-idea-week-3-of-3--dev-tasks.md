---
name: 'Choosing Idea Week 3 of 3: Dev Tasks'
about: FOR CHOOSING IDEA Week 3 Checklist for Devs
title: "[Topic Name] [Project Name] Week 3 of 3: Dev Tasks"
labels: weekly-dev
assignees: ''

---

# Week 3 of 3: Presentation, Implementing Feedback
## Week 3 Checklist for Devs
Conduct Zoom Presentation
Integrate all Feedback on Slides, Lab and Presentation
