---
name: 'Choosing Idea Week 3 of 3: Manager Tasks'
about: FOR CHOOSING IDEA Week 3 Checklist for Managers
title: "[Topic Name] [Project Name] Week 3 of 3: Manager Tasks"
labels: weekly-manager
assignees: ''

---

# Week 3 of 3: Presentation, Implementing Feedback
## Week 3 Checklist for Managers
- [ ] Follow-up with devs to integrate all feedback on slides, lab and presentation
- [ ] Attend devs' presentation and submit feedback
