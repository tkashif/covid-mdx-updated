---
name: 'Choosing Idea Week 2 of 3: Manager Tasks'
about: FOR CHOOSING IDEA Week 2 Checklist for Managers
title: "[Topic Name] [Project Name] Week 2 of 3: Manager Tasks"
labels: weekly-manager
assignees: ''

---

# Week 2 of 3: Finalizing Materials
## Week 2 Checklist for Managers
- [ ] Follow-up with devs to completely finalize slides
- [ ] Delegate specific responsibilities for lab conversion
- [ ] Provide insight on all speaker notes for every slide
- [ ] Dry run entire presentation 
- [ ] Double-check with head on time of the presentation
