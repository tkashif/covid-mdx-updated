---
name: 'Choosing Idea Week 2 of 3: Dev Tasks'
about: FOR CHOOSING IDEA Week 2 Checklist for Devs
title: "[Topic Name] [Project Name] Week 2 of 3: Dev Tasks"
labels: weekly-dev
assignees: ''

---

# Week 2 of 3: Finalizing Materials
## Week 2 Checklist for Devs
- [ ] Finalize slides per manager's feedback
- [ ] Convert slides into lab format
- [ ] Prepare presentation
         - [ ] Finalize speaker notes
         - [ ] Confirm date and time with Head
