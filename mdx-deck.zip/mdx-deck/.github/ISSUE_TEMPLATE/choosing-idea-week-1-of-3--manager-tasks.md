---
name: 'Choosing Idea Week 1 of 3: Manager Tasks'
about: FOR CHOOSING IDEA Week 1 Checklist for Managers
title: "[Topic Name] [Project Name] Week 1 of 3: Manager Tasks"
labels: weekly-manager
assignees: ''

---

#Week 1 of 3: Getting Ideas on (MDX-Deck) Paper
##Week 1 Checklist for Managers
- [ ] Ensure they have mdx-deck working on their computers
- [ ] Come up with specific action plan for how devs will convert slides
- [ ] Discuss with devs to coordinate and confirm the interactive component
- [ ] Confirm date and time of presentation in Week 3 with head and devs
- [ ] "General Manager Responsibility" checklist should be completed
